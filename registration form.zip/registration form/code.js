function myfun(){
    var usernsme1=document.getElementById('username').value;
    // alert("sandeep")
    var email1=document.getElementById('email').value;
    var password1=document.getElementById('password').value;
    var password2=document.getElementById('password2').value;
    var phone=document.getElementById('phone').value;
    var usercheck=/^[a-zA-Z0-9]+([a-zA-Z0-9](_|-| )[a-zA-Z0-9])*[a-zA-Z0-9]+$/;
    var city=document.getElementById('city').value;
    var city2=/^[a-zA-z0-9]{3,20}$/
    var dob=document.getElementById('dob').value;
    var sel=document.getElementById('inputState').value;
    
    
    var em=	
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var pas1=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
    // var cpas=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/
    var p=/^[6879]\d{9}$/;




// #=================================user validation================================================#

    if(usernsme1!=""){
        document.getElementById('usernameerror2').innerHTML="";
        
    }
    else{
        document.getElementById('usernameerror2').innerHTML="Please enter your name";
        return false;

    }

    if(usercheck.test(usernsme1)){
        document.getElementById('usernameerror').innerHTML="";
        
    }
    else{
        document.getElementById('usernameerror').innerHTML="Invalid user name";
        return false;
    
    }

// #================================email validation================================================#


    
    if(email1!="" ){
        document.getElementById('emailerror2').innerHTML="";
    }
    else{
        document.getElementById('emailerror2').innerHTML="Please enter your email";
        return false;


    }
    if(em.test(email1)){
        document.getElementById('emailerror').innerHTML="";
    }
    else{
        document.getElementById('emailerror').innerHTML="Invalid user email";
        return false;


    }
// #================================password validation================================================#   


    if(pas1.test(password1)  && password1!="" ){
        document.getElementById('passworderror').innerHTML="";
        
    }
    else{
        document.getElementById('passworderror').innerHTML="Please type one spacial char and number  ";
        return false;


    }
    if(password1.match(password2 ) && password2!=""){
        document.getElementById('confermerror').innerHTML="";
    }
    else{
        document.getElementById('confermerror').innerHTML=" Password Matching error";
        return false;

// #================================DOB validation================================================#   
    }
    if(dob!=""){
        document.getElementById('dob2').innerHTML="";

    }else{
        document.getElementById('dob2').innerHTML=" Please enter your date of birth";
        return false;

    }

// #================================phone validation================================================#

    if(p.test(phone) && phone!=""){
        document.getElementById('phoneerror').innerHTML="";
    }
    else{
        document.getElementById('phoneerror').innerHTML="Invalid phone number";
        return false;


    }
// #================================city validation================================================#


    if(city2.test(city) && city!="" || (city.length<=3 &&city.length>=15)){
        document.getElementById('cityerror').innerHTML="";

    }else{
        document.getElementById('cityerror').innerHTML="Please type valid city name";
        return false;


    }
    

    

    
    var alldata="Your all details is -"+"\n"+
                "User Name : " +usernsme1 +"\n"+
                "User Email : "  + email1+"\n"+
                "User Mobile : "+phone+"\n"+
                "Date Of Birth : "+ dob+"\n"+
                "User city/ZipCode : "+city+"\n"+
                "User city : "+sel+"\n";
              
               
                
   confirm(alldata);

}


// function login(){
//     var usernsme1=document.getElementById('username').value;
//     var password1=document.getElementById('password').value;
//     var lusr=document.getElementById('username5').value;
//     var plusr=document.getElementById('password5').value;
//     if(usernsme1== lusr){
//         document.getElementById('usernameerror').innerHTML="correct";

//     }
//     else{
//         document.getElementById('usernameerror').innerHTML="user does not exit";
//         return false;

//     }
//     if(password1== plusr){
//         document.getElementById('emailerror').innerHTML="oyo";

//     }
//     else{
//         document.getElementById('emailerror').innerHTML="incorrect password";
//         return false;

//     }


// }